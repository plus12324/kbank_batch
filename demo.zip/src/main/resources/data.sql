INSERT INTO Products (prod_name, prod_price) values ('a', 2700);
INSERT INTO Products (prod_name, prod_price) values ('b', 35180);
INSERT INTO Products (prod_name, prod_price) values ('c', 860);
INSERT INTO Products (prod_name, prod_price) values ('d', 2900);