package com.example.demo;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.batch.MyBatisBatchItemWriter;
import org.mybatis.spring.batch.MyBatisPagingItemReader;
import org.mybatis.spring.batch.builder.MyBatisBatchItemWriterBuilder;
import org.mybatis.spring.batch.builder.MyBatisPagingItemReaderBuilder;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.batch.BatchDataSource;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import com.zaxxer.hikari.HikariDataSource;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class DemoConfig {
	@Qualifier("dataSource_mysql")	
	private final DataSource dataSource;
	private final ApplicationContext applicationContext;

	private final JobBuilderFactory jobBuilderFactory; // Job ���� ������
	private final StepBuilderFactory stepBuilderFactory; // Step ���� ������

	@Bean
	public Job demoJob() throws Exception {
		System.out.println("demojob running...");
//		return jobBuilderFactory.get("demoJob"+LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")))
		return jobBuilderFactory.get("demoJob")
				.start(demoStep()).build();
	}

	@Bean
	public Step demoStep() throws Exception {
		log.info("demostep running...");
		return stepBuilderFactory.get("demoStep1")
				.<HashMap, HashMap>chunk(10)
				.reader(myBatisItemReader())
				.processor(processor())
				.writer(sampleItemWriter()).build();
	}

//	@Bean
//	@StepScope
//	public ItemReader<HashMap> myBatisItemReader() throws Exception {
//		Map<String, Object> parameterValues = new HashMap<>();
//	    parameterValues.put("seq", 6);
//	    return new MyBatisPagingItemReaderBuilder<Map>()
//		    .pageSize(1000)
//		    .sqlSessionFactory(sqlSessionFactory())
//		    .queryId("TestTableMapper.selectTest")
//		    .parameterValues(parameterValues)
//		    .build();
//	}

	@Bean
	@StepScope
	public ItemReader<HashMap> myBatisItemReader() throws Exception {
		log.info("ItemReader running...");
		MyBatisPagingItemReader<HashMap> reader = new MyBatisPagingItemReader<HashMap>();
		reader.setSqlSessionFactory(sqlSessionFactory());
		reader.setQueryId("TestTableMapper.selectTest");

		return reader;
	}

	public ItemProcessor<HashMap, HashMap> processor() {
		return map -> {
			Iterator<Entry<Integer, String>> it = map.entrySet().iterator();
			while (it.hasNext()) {
				Entry<Integer, String> entrySet = (Entry<Integer, String>) it.next();
				// key, value ���
				System.out.println(String.valueOf(entrySet.getKey())  + " : " + String.valueOf(entrySet.getValue()));
				//���������� ���Խ� ���� Ű ��ҹ��� �����Ͽ� �Է��Ұ�.
			}

//	    	map.entrySet().stream().forEach(entry-> {
//	    		System.out.println("[key]:" + entry.getKey() + ", [value]:"+entry.getValue());
//	    	});
			return map;
		};
	}

	public ItemWriter<HashMap> sampleItemWriter() throws Exception {
		log.info("ItemWriter running...");
		MyBatisBatchItemWriter<HashMap> writer = new MyBatisBatchItemWriter<HashMap>();
        writer.setSqlSessionFactory(sqlSessionFactory());
//        writer.setStatementId("TestTableMapper.insertTest");
        writer.setStatementId("TestTableMapper.insertTest_mysql");
		return writer;
	}

	
	@Bean
	public SqlSessionFactory sqlSessionFactory() throws Exception {
		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
		sqlSessionFactoryBean.setDataSource(dataSource);
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath:mappers/*.xml"));

		return sqlSessionFactoryBean.getObject();
	}
}
