package com.eai.online;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ResHeaderPartDto {
    private String field1;
    private String field2;
    private Integer field3;
    
    @JsonCreator
    public ResHeaderPartDto(@JsonProperty("field3") Object field3) {
    	this.field3 = Integer.parseInt((String) field3);
    }
}
