package com.eai.online;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.filter.factory.rewrite.ModifyResponseBodyGatewayFilterFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class CustomJsonTypePostFilter extends AbstractGatewayFilterFactory<CustomJsonTypePostFilter.Config> {

	private final ObjectMapper objectMapper;
	private final ModifyResponseBodyGatewayFilterFactory modifyResponseBodyGatewayFilterFactory;

	public CustomJsonTypePostFilter(ObjectMapper objectMapper,
			ModifyResponseBodyGatewayFilterFactory modifyResponseBodyGatewayFilterFactory) {
		super(Config.class);
		this.objectMapper = objectMapper;
		this.modifyResponseBodyGatewayFilterFactory = modifyResponseBodyGatewayFilterFactory;
	}

	public static class Config {
		// Put configuration properties here
	}

	@Override
    public GatewayFilter apply(Config config) {
        ModifyResponseBodyGatewayFilterFactory.Config modifyResponseConfig = new ModifyResponseBodyGatewayFilterFactory.Config()
            .setRewriteFunction(String.class, String.class, (exchange, originalBody) -> {
                
            String modifiedResBody;
        	ResHeaderPartDto dto;                            
            log.info("■3■ Before postFilter : " + originalBody);
            try {                                        	
            	dto = objectMapper.readValue(originalBody, ResHeaderPartDto.class);
             	modifiedResBody = objectMapper.writeValueAsString(dto);
              	log.info("■4■ After postFilter : " + modifiedResBody);              	
            } catch (Exception e) {
                // data 수정 없이 return
                return Mono.just(originalBody);
            }

            	
            return Mono.just(modifiedResBody);
            });

        return modifyResponseBodyGatewayFilterFactory.apply(modifyResponseConfig);
    }

}
