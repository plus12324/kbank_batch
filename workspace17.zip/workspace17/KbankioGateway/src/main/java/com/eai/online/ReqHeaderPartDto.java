package com.eai.online;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReqHeaderPartDto {
    private String field1;
    private String field2;
    private String field3;
    
    @JsonCreator
    public ReqHeaderPartDto(@JsonProperty("field3") Object field3) {
    	this.field3 = field3.toString();
    }

}
