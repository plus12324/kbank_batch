package com.eai.online;

import java.io.IOException;

import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.filter.factory.rewrite.ModifyRequestBodyGatewayFilterFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class CustomJsonTypePreFilter extends AbstractGatewayFilterFactory<CustomJsonTypePreFilter.Config> {

	private final ObjectMapper objectMapper;
	private final ModifyRequestBodyGatewayFilterFactory modifyRequestBodyGatewayFilterFactory;

    public CustomJsonTypePreFilter(ObjectMapper objectMapper, ModifyRequestBodyGatewayFilterFactory modifyRequestBodyGatewayFilterFactory) {
        super(Config.class);
        this.modifyRequestBodyGatewayFilterFactory = modifyRequestBodyGatewayFilterFactory;
        this.objectMapper = objectMapper;
    }


    public static class Config {
        // Put configuration properties here
    }

    @Override
    public GatewayFilter apply(Config config) {
        ModifyRequestBodyGatewayFilterFactory.Config modifyRequestConfig = new ModifyRequestBodyGatewayFilterFactory.Config()
            .setRewriteFunction(String.class, String.class, (exchange, originalBody) -> {
                // 요청 본문 타입변경            	
                ReqHeaderPartDto dto;
                try {
                	log.info("■1■ Before preFilter : " + originalBody);
                	dto = objectMapper.readValue(originalBody, ReqHeaderPartDto.class);
                    // JSON이 MyDto와 일치함
                } catch (IOException e) {
                    // JSON이 MyDto와 일치하지 않음
                    return Mono.error(new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid JSON format"));
                }

                // 변경된 요청 본문을 다시 설정
                String modifiedBody;
                try {
                    modifiedBody = objectMapper.writeValueAsString(dto);
                    log.info("■2■ After preFilter : " + modifiedBody);
                } catch (JsonProcessingException e) {
                    return Mono.error(new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error processing JSON"));
                }

                return Mono.just(modifiedBody);
            });

        return modifyRequestBodyGatewayFilterFactory.apply(modifyRequestConfig);
    }
    
}
