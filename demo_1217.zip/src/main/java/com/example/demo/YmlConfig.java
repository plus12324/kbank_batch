package com.example.demo;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Configuration
@PropertySource(value = "classpath:datasource.yaml", factory = YamlPropertySourceFactory.class)
@ConfigurationProperties(prefix = "DBMS")
@Getter
@Setter
@RequiredArgsConstructor
public class YmlConfig {
	
	List<DataSourceInfo> list;
//	@Value("${username}")
//	private String username;
	
	
}
