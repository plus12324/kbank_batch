package com.example.demo;

import java.sql.Connection;

import javax.sql.DataSource;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Component
public class DemoRunner implements ApplicationRunner {

	final DataSource dataSource;
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		// TODO Auto-generated method stub
		Connection connection = dataSource.getConnection();
		log.info("h2 Url: " + connection.getMetaData().getURL());
		log.info("h2 UserName: " + connection.getMetaData().getUserName());
	}

}
